import PlaygroundSupport
import SpriteKit

let skView = SKView(frame: CGRect(origin: .zero, size: CGSize(width: 1024, height: 768)))
let controller = GameViewController()
controller.view = skView
controller.viewDidLoad()

PlaygroundPage.current.liveView = controller
PlaygroundPage.current.needsIndefiniteExecution = true

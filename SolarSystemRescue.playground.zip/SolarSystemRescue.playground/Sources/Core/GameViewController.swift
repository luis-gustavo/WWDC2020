//
//  GameViewController.swift
//  wwdc2020
//
//  Created by Luis Gustavo Avelino de Lima Jacinto on 08/05/20.
//  Copyright © 2020 Luis Gustavo Avelino de Lima Jacinto. All rights reserved.
//

import UIKit
import SpriteKit

public class GameViewController: UIViewController {

    public override func viewDidLoad() {
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(startNewScene), name: .replay, object: nil)

        startNewScene()
    }

    deinit {
        NotificationCenter.default.removeObserver(self, name: .replay, object: nil)
    }

    @objc public func startNewScene() {
        guard let view = view as? SKView else {
            fatalError("View must be of type: \(type(of: SKView.self))")
        }
        view.ignoresSiblingOrder = true
        let gameScene = GameScene(size: CGSize(width: 1024, height: 768))
        gameScene.scaleMode = .aspectFit
        view.presentScene(gameScene)
    }

    public override var shouldAutorotate: Bool {
        return true
    }

    public  override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }

    public override var prefersStatusBarHidden: Bool {
        return true
    }
}

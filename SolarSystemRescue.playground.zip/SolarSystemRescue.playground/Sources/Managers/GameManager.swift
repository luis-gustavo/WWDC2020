//
//  GameManager.swift
//  wwdc2020
//
//  Created by Luis Gustavo Avelino de Lima Jacinto on 13/05/20.
//  Copyright © 2020 Luis Gustavo Avelino de Lima Jacinto. All rights reserved.
//

import Foundation

class GameManager {
    static let shared = GameManager()

    var inCustscene: Bool = false
    var planetsCollected: Int = 0
    var isInFirstPart: Bool = true
    var inIntro: Bool = true

    private init () { }

    func initialize() {
        self.inCustscene = false
        self.planetsCollected = 0
        self.isInFirstPart = true
        self.inIntro = true
        NotificationCenter.default.addObserver(self, selector: #selector(planetCollected(_:)), name: .planetCollected, object: nil)
    }

    @objc private func planetCollected(_ notification: Notification) {
        planetsCollected += 1
        if planetsCollected == 8 {
            NotificationCenter.default.post(name: .collectedAllPlanets, object: nil)
            NotificationCenter.default.removeObserver(self, name: .planetCollected, object: nil)
        }
    }

    func gameOver() {
        isInFirstPart = true
        planetsCollected = 0
        inCustscene = false
        inIntro = true
        NotificationCenter.default.removeObserver(self, name: .planetCollected, object: nil)
    }
}
